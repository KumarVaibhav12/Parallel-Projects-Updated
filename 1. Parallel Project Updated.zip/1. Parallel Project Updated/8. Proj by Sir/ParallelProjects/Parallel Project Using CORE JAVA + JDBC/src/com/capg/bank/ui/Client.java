package com.capg.bank.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.capg.bank.bean.BankBean;
import com.capg.bank.service.BankServiceImpl;

public class Client {

	public static void main(String[] args) {
		BankServiceImpl bsi = new BankServiceImpl();
		Scanner sc = new Scanner(System.in);
		int ch;
		do {
			System.out.println("\n\t\t\t\tWelcome to My Bank Services");
			System.out.println("********************************************************************************************************");
			System.out.println(
					"1.Create Account\n2.Show Balance\n3.Deposit Amount\n4.Withdraw Amount\n5.FundTransfer\n6.Print Transaction Details\n7.Exit");
			System.out.print("Enter Your Choice: ");
			ch = sc.nextInt();
			switch (ch) {
			case 1:
				System.out.print("Enter Name:");
				String name = sc.next();
				System.out.print("Enter Mobile Number: ");
				String mobileno = sc.next();
				System.out.print("Enter Initial Amount: ");
				double amount = sc.nextDouble();
				System.out.print("Enter City: ");
				String city = sc.next();
				System.out.print("Enter State: ");
				String state = sc.next();
				BankBean bean = new BankBean(name, mobileno, amount, city, state);
				BankBean b = bsi.addAccount(bean);
				System.out.println("------------------------------------------------------------");
				System.out.println("Thank you " + name + " Your Account is created Successully");
				System.out.println("Your Account Id " + b.getAccount_id());
				break;
			case 2:
				System.out.print("Enter Account Id: ");
				int account_id = sc.nextInt();
				b = bsi.getAccountBalence(account_id);
				System.out.println("-------------------------------------------------------------------------");
				System.out.println(
						"Hello " + b.getCustomer_name() + "\nYour Current Account Balance is " + b.getAmount());
				break;
			case 3:
				System.out.print("Enter Account Id: ");
				account_id = sc.nextInt();
				System.out.print("Enter Amount to be Deposited: ");
				amount = sc.nextDouble();
				b = bsi.deposit(account_id, amount);
				System.out.println("------------------------------------------------------------------------");
				System.out.println("Hello " + b.getCustomer_name() + " Your Amount is Deposited Succesfully");
				System.out.println("Your Current Account Balence is " + b.getAmount());
				break;
			case 4:
				System.out.print("Enter Account Id: ");
				account_id = sc.nextInt();
				System.out.print("Enter Amount to be WithDrawn: ");
				amount = sc.nextDouble();
				b = bsi.withdraw(account_id, amount);
				System.out.println("------------------------------------------------------------------------");
				System.out.println("Hello " + b.getCustomer_name() + " Your Amount is Withdrawn Succesfully");
				System.out.println("Your Current Account Balence is " + b.getAmount());
				break;
				
			case 5:System.out.print("Enter Your Account Id: ");
			int account_id1 = sc.nextInt();
			System.out.print("Enter Account Id of person you want to transfer Amount: ");
			int account_id2 = sc.nextInt();
			System.out.print("Enter Amount to be Transfered: ");
			amount = sc.nextDouble();
			b = bsi.fundTransfer(account_id1, account_id2, amount);
			System.out.println("-----------------------------------------------------------------------------");
			System.out.println("Hello " + b.getCustomer_name() + " Your Amount is Transferred Succesfully\n");
			System.out.println("Your Current Account Balence is " + b.getAmount());

				
				break;
			case 6:
				System.out.print("Enter Your Account Number to Know Your Transaction Details:");
				account_id = sc.nextInt();
				ArrayList a = bsi.printDetails(account_id);
				System.out.println("Transaction_Id Account_Id    Transaction_Date     Transaction_Amount Transaction_Type");
				System.out.println("_______________________________________________________________________________________");
				for(Object i:a)
				System.out.println(i+"\n");
				System.out.println("_______________________________________________________________________________________");
				break;
			case 7:
				System.out.println("Thank for Using our Bank Services....!!!");
				break;

			}

		} while (ch != 7);
	}

}
