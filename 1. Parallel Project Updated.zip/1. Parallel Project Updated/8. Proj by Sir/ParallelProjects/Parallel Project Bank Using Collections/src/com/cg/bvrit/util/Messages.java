package com.cg.bvrit.util;

public class Messages {

	public final static String INSUFFICIENT_BALANCE=" Insufficient Balance ";

	public Messages() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	
}
