package com.bank._SpringBoot_ParallelProject.controller;

import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bank._SpringBoot_ParallelProject.entities.TransactionBean;
import com.bank._SpringBoot_ParallelProject.entities.UserBean;
import com.bank._SpringBoot_ParallelProject.exceptions.GlobalException;
import com.bank._SpringBoot_ParallelProject.services.BankServiceimpl;

@RestController
@RequestMapping("/Bank")
public class RestApiController {

	@Autowired
	private BankServiceimpl service; // bankService Class Object Creation

	@PostMapping(value = "/create")  // create - Post 
	public UserBean addUserData(@Valid @RequestBody final UserBean usr) {
		return service.userAccountCreation(usr);
	}

	
	@GetMapping(value = "/login/id/{id}/password/{password}") // Login - Get 
	public UserBean Login(@PathVariable final int id, @PathVariable final String password) {
		return service.Login(id, password);
	}
	
	@GetMapping(value = "/balance/{id}")  // ShowBalance - Get 
	public int displayBalance(@Valid @PathVariable final int id) {
		int i = service.displayBalance(id);
		if (i == -1) {
			throw new GlobalException("Failed");
		}
		return i;
	}
	
	
	
	
	@PutMapping(value = "/deposit/{id}/{balance}")  // deposit - Put 
	public int depositBalance(@Valid @RequestBody final UserBean usr) {
		int i = service.depositBalance(usr);
		if (i == -1) {
			throw new GlobalException("Deposit Failed");
		}
		return i;
	}

	@PutMapping(value = "/withdraw/{id}/{balance}")  // withdraw - Put
	public int withdrawBalance(@Valid @RequestBody final UserBean usr) {
		int i = service.withdrawBalance(usr);
		if (i == -1) {
			throw new GlobalException("Withdraw Failed");
		}
		return i;
	}

	

	@PutMapping(value = "/fundtransfer/{accountId}")  // FundTransfer - Put 
	public int fundTransfer(@Valid @PathVariable final int accountId, @RequestBody final UserBean usr) {
		int i = service.fundTransfer(accountId, usr);
		if (i == -1) {
			throw new GlobalException("Transfer Failed");
		}
		return i;
	}

	@GetMapping(value = "/transactions/{id}")  // Transaction - Get 
	public Set<TransactionBean> printTransaction(@Valid @PathVariable final int id) {
		return service.transactionList(id);
	}

	

}
