package com.bank._SpringBoot_ParallelProject.exceptions;

public class InvalidAuthentication extends RuntimeException {

	/**
	* 
	*/
	private static final long serialVersionUID = 1L;

	public InvalidAuthentication(String msg) {
		super(msg);
	}

	public InvalidAuthentication() {
	}

}
