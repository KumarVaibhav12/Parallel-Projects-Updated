package com.bank.service;

import java.util.List;

import javax.security.auth.login.AccountNotFoundException;

import com.bank.user.bean.TransactionBean;

public interface BankServiceInterface {

	// Service methods
	String userAccountCreate(String accountPassword, String userName, long mobileNumber);

	int Login(int accountId, String accountPassword);

	String showBalance(int accountId);

	String deposit(int accountId, int amount);

	String withDraw(int accountId, int amount);

	String fundTransfer(int sourceAccountId, int destinationAccountId, int amount) throws AccountNotFoundException;

	String printTransactions(int accountId);
	
	
	

	// validation methods.
	String validAccountId(String accountId);  // for accountvalidation

	String checkBalance(String accountId, String amount); //for balance check

	String nameCheck(String userName); // for name check

	String passwordCheck(String password); // for password check

	String mobileNumberCheck(String mobileNumber); // for mobilechec

	String amountLimitCheck(String amount); // for amountlimit check

}