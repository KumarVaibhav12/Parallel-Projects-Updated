package com.bank._SpringBoot_ParallelProject.services;

import java.util.List;
import java.util.Set;

import javax.validation.Valid;

import com.bank._SpringBoot_ParallelProject.entities.TransactionBean;
import com.bank._SpringBoot_ParallelProject.entities.UserBean;

public interface BankServiceInterface {

	UserBean userAccountCreation(UserBean ub);

	UserBean Login(int accId, String accPassword);

	int displayBalance(int accId);

	int depositBalance(UserBean ub);

	int withdrawBalance(UserBean ub);

	int fundTransfer(int accountId, UserBean ub);

	Set<TransactionBean> transactionList(int accountId);

	//List<TransactionBean> printTranscation(@Valid String accountId);

}
